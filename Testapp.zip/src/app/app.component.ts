import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'testApp';

  countries: any[] = [ 
        {"name": "Afghanistan", "code": "AF"}, 
        {"name": "Åland Islands", "code": "AX"}, 
        {"name": "Albania", "code": "AL"}, 
        {"name": "Algeria", "code": "DZ"}
    ];
  selectedCountryAdvanced: any[] | undefined;
  filteredCountries!: any[];


  filterCountry(event: { query: any; }) {    
    let filtered: any[] = [];
    let query = event.query;    
    for (let i = 0; i < this.countries.length; i++) {      
      let country = this.countries[i];      
      if (country.name.toLowerCase().includes( query.toLowerCase() )) {        
        filtered.push(country);        
      }
    }

    this.filteredCountries = filtered;
  }
}
